import PropTypes from "prop-types";
const UserData = [
    {
        name :"NIJITHA MOL M", 
        city:"Palakkad",
        description:"Full Stack Developer",
        skills:["UI/UX","Front-end Developer","HTML","CSS",
        "JavaScript","Node","React"],
        online:true,
        profile:"img/user 2.jpg"
    },
    {
        name :"KAVINA SRI DEVI G", 
        city:"Coimbatore",
        description:"Full Stack Developer",
        skills:["UI/UX","Front-end Developer","HTML","CSS",
        "JavaScript","Node","React"],
        online: false,
        profile:"img/user 3.jpg"
    },
    
    {
        name :"ABDUL RAHMAN ANAS A", 
        city:"Pudukottai",
        description:"Full Stack Developer",
        skills:["UI/UX","Front-end Developer","HTML","CSS",
        "JavaScript","Node","React"],
        online: true,
        profile:"img/user 4.jpg"
    },
    {
        name :"PRIYANGA K", 
        city:"Nilgiris",
        description:"Full Stack Developer",
        skills:["UI/UX","Front-end Developer","HTML","CSS",
        "JavaScript","Node","React"],
        online: false,
        profile:"img/user 1.jpg"
    },
    {
        name :"VIJAY KARTHICK R", 
        city:"Salem",
        description:"Full Stack Developer",
        skills:["UI/UX","Front-end Developer","HTML","CSS",
        "JavaScript","Node","React","Java"],
        online: false,
        profile:"img/user 5.jpg"
    },
    
]


function User (props) {
    return (
        <div className="card-container">
            <span className={props.online?"pro online":"pro offline"}>{props.online?"ONLINE":"OFFLINE"}</span>
            <img src={props.profile} alt="user"  className="img"/>
            <h3>{props.name}</h3>
            <h3>{props.city}</h3>
            <p>{props.description}</p>
            <div className="buttons">
                <button className="primary">Message</button>
                <button className="primary outline">Following</button>
            </div>
            <div className="skills">
                <h6>SKILLS</h6>
                <ul>{props.skills.map((skills,index)=>(
                    <li key={index}>{skills}</li>
                ))}</ul>
            </div>
        </div>
        
    )
}
export const UserCard = () => {
    return(
        <>
            {UserData.map((user,index)=>(
                <User key={index}
                name={user.name}
                city={user.city}
                description={user.description}
                online={user.online}
                profile={user.profile}
                skills={user.skills}/>
            ))}
        </>
    )
}

{
    /*<User name="NIJITHA MOL M" city="Coimbatore" description="Full Stack Developer"
         skills={["UI/UX","Front-end Developer","HTML","CSS","JavaScript","Node","React"]}/>*/
}

User.propTypes = {
    name: PropTypes.string.isRequired,
    city: PropTypes.string.isRequired,
    description:PropTypes.string.isRequired,
    online: PropTypes.bool.isRequired,
    skills: PropTypes.arrayOf(PropTypes.string).isRequired,
    profile: PropTypes.string.isRequired
}

